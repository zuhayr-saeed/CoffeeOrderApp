public class BasicCoffee implements Coffee {

    private double cost = 4.50;
    private String description = "Black Coffee";

    @Override
    public double makeCoffee() {
        System.out.println(getDescription() + ": $" + String.format("%.2f", cost));
        return cost;
    }

    @Override
    public String getDescription() {
        return description;
    }

    @Override
    public double getCost() {
        return cost;
    }
}
