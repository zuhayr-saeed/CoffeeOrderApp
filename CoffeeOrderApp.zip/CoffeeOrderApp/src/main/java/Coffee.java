public interface Coffee {
    double makeCoffee();
    String getDescription();
    double getCost();
}
