import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.Label;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.shape.Rectangle;
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.animation.RotateTransition;
import javafx.animation.SequentialTransition;
import javafx.util.Duration;

public class CoffeeOrderController {

    @FXML
    private CheckBox extraShotCheckBox;

    @FXML
    private CheckBox creamCheckBox;

    @FXML
    private CheckBox sugarCheckBox;

    @FXML
    private CheckBox whippedCreamCheckBox;

    @FXML
    private CheckBox vanillaSyrupCheckBox;

    @FXML
    private TextArea orderTextArea;

    @FXML
    private Label totalLabel;

    @FXML
    private Rectangle decorativeRect;

    private OrderBuilder orderBuilder;

    public void initialize() {
        startNewOrder();
    }

    @FXML
    private void handleNewOrder() {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("New Order");
        alert.setHeaderText("Start a New Order");
        alert.setContentText("Are you sure you want to start a new order? Current order will be cleared.");

        if (alert.showAndWait().get() == javafx.scene.control.ButtonType.OK){
            startNewOrder();
        }
    }

    @FXML
    private void handleDeleteOrder() {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Delete Order");
        alert.setHeaderText("Delete Current Order");
        alert.setContentText("Are you sure you want to delete the current order?");

        if (alert.showAndWait().get() == javafx.scene.control.ButtonType.OK){
            startNewOrder();
        }
    }

    @FXML
    private void handleAddToOrder() {
        if (orderBuilder == null) {
            orderBuilder = new OrderBuilder();
        }

        boolean anySelected = false;

        if (extraShotCheckBox.isSelected()) {
            orderBuilder.addExtraShot();
            anySelected = true;
        }

        if (creamCheckBox.isSelected()) {
            orderBuilder.addCream();
            anySelected = true;
        }

        if (sugarCheckBox.isSelected()) {
            orderBuilder.addSugar();
            anySelected = true;
        }

        if (whippedCreamCheckBox.isSelected()) {
            orderBuilder.addWhippedCream();
            anySelected = true;
        }

        if (vanillaSyrupCheckBox.isSelected()) {
            orderBuilder.addVanillaSyrup();
            anySelected = true;
        }

        if (!anySelected) {
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("No Add-Ons Selected");
            alert.setHeaderText(null);
            alert.setContentText("Please select at least one add-on before adding to the order.");
            alert.showAndWait();
            return;
        }

        updateOrderDisplay();

        // Reset checkboxes after adding to order
        resetCheckBoxes();
    }

    private void startNewOrder() {
        orderBuilder = new OrderBuilder();
        orderTextArea.clear();
        totalLabel.setText("Total: $0.00");

        // Uncheck all checkboxes
        resetCheckBoxes();
    }

    private void resetCheckBoxes() {
        extraShotCheckBox.setSelected(false);
        creamCheckBox.setSelected(false);
        sugarCheckBox.setSelected(false);
        whippedCreamCheckBox.setSelected(false);
        vanillaSyrupCheckBox.setSelected(false);
    }

    private void updateOrderDisplay() {
        if (orderBuilder == null) return;

        String orderDescription = orderBuilder.getOrderDescription();
        orderTextArea.setText(orderDescription);

        double total = orderBuilder.getTotalCost();
        totalLabel.setText(String.format("Total: $%.2f", total));
    }

    // Method to apply transitions to the decorative Rectangle
    public void applyTransitions() {
        // Rotate Transition
        RotateTransition rotate = new RotateTransition(Duration.millis(5000), decorativeRect);
        rotate.setByAngle(270);
        rotate.setCycleCount(4);
        rotate.setAutoReverse(true);

        // Fade Transition
        FadeTransition fade = new FadeTransition(Duration.millis(5000), decorativeRect);
        fade.setFromValue(1.0);
        fade.setToValue(0.3);
        fade.setCycleCount(4);
        fade.setAutoReverse(true);

        // Sequential Transition
        SequentialTransition seqTransition = new SequentialTransition(
            new PauseTransition(Duration.millis(500)),
            rotate
        );

        // Play Transitions
        seqTransition.play();
        fade.play();
    }
}
