public class ExtraShot extends CoffeeDecorator {

    private double cost = 1.20;
    private String description = "Extra Shot";

    public ExtraShot(Coffee specialCoffee) {
        super(specialCoffee);
    }

    @Override
    public double makeCoffee() {
        double total = super.makeCoffee() + addShot();
        return total;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "\n + " + description + ": $" + String.format("%.2f", cost);
    }

    @Override
    public double getCost() {
        return cost;
    }

    private double addShot() {
        System.out.println(" + " + description + ": $" + String.format("%.2f", cost));
        return cost;
    }
}
