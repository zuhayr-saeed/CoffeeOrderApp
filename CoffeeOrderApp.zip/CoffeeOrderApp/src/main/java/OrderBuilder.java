public class OrderBuilder {
    private Coffee order;
    private StringBuilder description;

    public OrderBuilder() {
        order = new BasicCoffee();
        description = new StringBuilder();
        description.append(order.getDescription()).append("\n");
    }

    public void addExtraShot() {
        order = new ExtraShot(order);
        description.append(" + Extra Shot: $1.20\n");
    }

    public void addCream() {
        order = new Cream(order);
        description.append(" + Cream: $0.50\n");
    }

    public void addSugar() {
        order = new Sugar(order);
        description.append(" + Sugar: $0.50\n");
    }

    public void addWhippedCream() {
        order = new WhippedCream(order);
        description.append(" + Whipped Cream: $0.75\n");
    }

    public void addVanillaSyrup() {
        order = new VanillaSyrup(order);
        description.append(" + Vanilla Syrup: $0.60\n");
    }

    public String getOrderDescription() {
        description.append(String.format("Total: $%.2f", order.makeCoffee()));
        return description.toString();
    }

    public double getTotalCost() {
        return order.makeCoffee();
    }
}
