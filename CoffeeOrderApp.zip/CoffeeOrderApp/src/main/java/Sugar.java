public class Sugar extends CoffeeDecorator {

    private double cost = 0.50;
    private String description = "Sugar";

    public Sugar(Coffee specialCoffee) {
        super(specialCoffee);
    }

    @Override
    public double makeCoffee() {
        double total = super.makeCoffee() + addSugar();
        return total;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "\n + " + description + ": $" + String.format("%.2f", cost);
    }

    @Override
    public double getCost() {
        return cost;
    }

    private double addSugar() {
        System.out.println(" + " + description + ": $" + String.format("%.2f", cost));
        return cost;
    }
}
