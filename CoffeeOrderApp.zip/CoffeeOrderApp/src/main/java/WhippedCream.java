public class WhippedCream extends CoffeeDecorator {

    private double cost = 0.75;
    private String description = "Whipped Cream";

    public WhippedCream(Coffee specialCoffee) {
        super(specialCoffee);
    }

    @Override
    public double makeCoffee() {
        double total = super.makeCoffee() + addWhippedCream();
        return total;
    }

    @Override
    public String getDescription() {
        return super.getDescription() + "\n + " + description + ": $" + String.format("%.2f", cost);
    }

    @Override
    public double getCost() {
        return cost;
    }

    private double addWhippedCream() {
        System.out.println(" + " + description + ": $" + String.format("%.2f", cost));
        return cost;
    }
}
