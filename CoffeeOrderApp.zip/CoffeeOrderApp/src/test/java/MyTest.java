import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyTest {

    @Test
    @DisplayName("Test Basic Coffee Cost")
    void testBasicCoffeeCost() {
        Coffee basicCoffee = new BasicCoffee();
        assertEquals(4.50, basicCoffee.makeCoffee(), 0.001, "Basic Coffee should cost $4.50");
    }

    @Test
    @DisplayName("Test Extra Shot Cost")
    void testExtraShotCost() {
        Coffee order = new ExtraShot(new BasicCoffee());
        assertEquals(5.70, order.makeCoffee(), 0.001, "Coffee with Extra Shot should cost $5.70");
    }

    @Test
    @DisplayName("Test Cream Cost")
    void testCreamCost() {
        Coffee order = new Cream(new BasicCoffee());
        assertEquals(5.00, order.makeCoffee(), 0.001, "Coffee with Cream should cost $5.00");
    }

    @Test
    @DisplayName("Test Sugar Cost")
    void testSugarCost() {
        Coffee order = new Sugar(new BasicCoffee());
        assertEquals(5.00, order.makeCoffee(), 0.001, "Coffee with Sugar should cost $5.00");
    }

    @Test
    @DisplayName("Test Whipped Cream Cost")
    void testWhippedCreamCost() {
        Coffee order = new WhippedCream(new BasicCoffee());
        assertEquals(5.25, order.makeCoffee(), 0.001, "Coffee with Whipped Cream should cost $5.25");
    }

    @Test
    @DisplayName("Test Vanilla Syrup Cost")
    void testVanillaSyrupCost() {
        Coffee order = new VanillaSyrup(new BasicCoffee());
        assertEquals(5.10, order.makeCoffee(), 0.001, "Coffee with Vanilla Syrup should cost $5.10");
    }

    @Test
    @DisplayName("Test Multiple Add-Ons Cost: Extra Shot, Cream, Sugar")
    void testMultipleAddOnsCost1() {
        Coffee order = new Sugar(new Cream(new ExtraShot(new BasicCoffee())));
        assertEquals(6.70, order.makeCoffee(), 0.001, "Coffee with Extra Shot, Cream, and Sugar should cost $6.70");
    }

    @Test
    @DisplayName("Test Multiple Add-Ons Cost: Sugar, Whipped Cream, Vanilla Syrup")
    void testMultipleAddOnsCost2() {
        Coffee order = new VanillaSyrup(new WhippedCream(new Sugar(new BasicCoffee())));
        assertEquals(6.35, order.makeCoffee(), 0.001, "Coffee with Sugar, Whipped Cream, and Vanilla Syrup should cost $6.35");
    }

    @Test
    @DisplayName("Test All Add-Ons Cost")
    void testAllAddOnsCost() {
        Coffee order = new VanillaSyrup(
                            new WhippedCream(
                                new Sugar(
                                    new Cream(
                                        new ExtraShot(new BasicCoffee())
                                    )
                                )
                            )
                        );
        assertEquals(8.05, order.makeCoffee(), 0.001, "Coffee with all add-ons should cost $8.05");
    }

    @ParameterizedTest(name = "Test Coffee with {0} add-ons")
    @ValueSource(ints = {0, 1, 2, 3, 4, 5})
    @DisplayName("Parameterized Test for Varying Number of Add-Ons")
    void testVaryingAddOns(int numberOfAddOns) {
        OrderBuilder builder = new OrderBuilder();
        double expectedCost = 4.50; // Basic Coffee cost

        if (numberOfAddOns >= 1) {
            builder.addExtraShot();
            expectedCost += 1.20;
        }
        if (numberOfAddOns >= 2) {
            builder.addCream();
            expectedCost += 0.50;
        }
        if (numberOfAddOns >= 3) {
            builder.addSugar();
            expectedCost += 0.50;
        }
        if (numberOfAddOns >= 4) {
            builder.addWhippedCream();
            expectedCost += 0.75;
        }
        if (numberOfAddOns >= 5) {
            builder.addVanillaSyrup();
            expectedCost += 0.60;
        }

        assertEquals(expectedCost, builder.getTotalCost(), 0.001,
            "Coffee with " + numberOfAddOns + " add-ons should cost $" + String.format("%.2f", expectedCost));
    }
}
